-- =====================================================================
-- ITC Field — seed data
--
-- Run after 01_schema.sql and 02_security.sql.
--
-- Pin positions are a starting guess. Once the app runs, use the admin
-- "Move pins" tool to place them properly and they'll save back here.
-- =====================================================================

-- ---------------------------------------------------------------------
-- ZONES
-- ---------------------------------------------------------------------
insert into zones (name, kind, pin_x, pin_y, sort_order) values
  ('MPA',                'Building', 0.2050, 0.5850,  1),
  ('MP0',                'Building', 0.1300, 0.2350,  2),
  ('MP1',                'Building', 0.3300, 0.6450,  3),
  ('MP2',                'Building', 0.5050, 0.6450,  4),
  ('MP3',                'Building', 0.6800, 0.6450,  5),
  ('MP4',                'Building', 0.4400, 0.2750,  6),
  ('MP5',                'Building', 0.6250, 0.2750,  7),
  ('MP6',                'Building', 0.8000, 0.2750,  8),
  ('A North',            'Road',     0.3850, 0.3000,  9),
  ('A South',            'Road',     0.3850, 0.6650, 10),
  ('B North',            'Road',     0.5650, 0.3000, 11),
  ('B South',            'Road',     0.5650, 0.6650, 12),
  ('C North',            'Road',     0.7450, 0.3000, 13),
  ('C South',            'Road',     0.7450, 0.6650, 14),
  ('Northern Haul Road', 'Road',     0.5000, 0.0750, 15),
  ('Eastern Haul Road',  'Road',     0.9250, 0.4800, 16),
  ('Southern Road',      'Road',     0.5200, 0.9050, 17),
  ('Central Spine Road', 'Road',     0.4700, 0.4700, 18);

-- ---------------------------------------------------------------------
-- SERVICES
-- HV and LV share dwg_group 'elec' so they resolve to the same drawing.
-- Comms and Comms Mains share 'comms'. Only hydraulic is pressurised,
-- which is what suppresses the CCTV step.
-- ---------------------------------------------------------------------
insert into services (id, name, colour, dwg_group, discipline, pressurised, sort_order) values
  ('hv',    'HV',           '#d13b2e', 'elec',  'elec',  false, 1),
  ('lv',    'LV',           '#7b3fa0', 'elec',  'elec',  false, 2),
  ('comms', 'Comms',        '#2f7fd0', 'comms', 'elec',  false, 3),
  ('cm',    'Comms Mains',  '#14406b', 'comms', 'elec',  false, 4),
  ('fire',  'Fire Comms',   '#b0264f', 'fire',  'elec',  false, 5),
  ('hyd',   'Hydraulic',    '#0f8a8a', 'hyd',   'hyd',   true,  6),
  ('sw',    'Stormwater',   '#2c8f7a', 'storm', 'drain', false, 7);

-- ---------------------------------------------------------------------
-- DRAWINGS
-- Only the MP0 electrical sheet is a confirmed number. The rest carry
-- '??' where the discipline code goes — deliberately obvious, so they
-- get corrected rather than trusted.
-- ---------------------------------------------------------------------
insert into drawings (drawing_no, title, dwg_group, zone_id, current_rev, issued_date)
select
  case when z.name = 'MP0' and g.grp = 'elec'
       then 'APP-SYD-MP-MP0-EL-SD-0010-00'
       else 'APP-SYD-MP-' || z.name || '-??-SD-' ||
            lpad((1000 + z.sort_order * 10 + g.ord)::text, 4, '0') || '-00'
  end,
  z.name || ' — ' || g.label || ' In-ground Services Overall',
  g.grp, z.id, 'A', current_date
from zones z
cross join (values
  ('elec',  'Electrical (HV & LV)', 1),
  ('comms', 'Communications',       2),
  ('fire',  'Fire',                 3),
  ('hyd',   'Hydraulic',            4),
  ('storm', 'Stormwater',           5)
) as g(grp, label, ord)
where z.kind = 'Building';

-- ---------------------------------------------------------------------
-- FORM DEFINITIONS
--
-- One version per service to begin with. The steps below are the
-- prototype's placeholders — replace the requirement text with your
-- real wording as it comes through, bumping the version each time.
-- ---------------------------------------------------------------------
insert into form_versions (service_id, version, is_current)
select id, 1, true from services;

-- Steps. Note the conditionals:
--   'Draw rope / mandrel'  only on electrical disciplines
--   'Registered surveyor topo' only on drainage
--   'CCTV survey' on everything that isn't pressurised
do $$
declare
  v record;
  s record;
  idx int;
  step_id uuid;
  req text;
  ridx int;
begin
  for v in
    select fv.id as fv_id, sv.id as svc, sv.discipline, sv.pressurised
    from form_versions fv join services sv on sv.id = fv.service_id
  loop
    idx := 0;
    for s in
      select * from (values
        ('Survey set-out', false,
          '[{"id":"rover","type":"select","label":"Rover used","source":"rovers","required":true},
            {"id":"op","type":"select","label":"Set out by","source":"operators","required":true}]'::jsonb,
          array['Set out from approved survey control',
                'Offsets and alignment marked on ground',
                'Checked against current drawing revision'], 'all'),
        ('Grade & depth', false, '[]'::jsonb,
          array['Grade checked against design levels',
                'Cover depth within specified tolerance',
                'Levels recorded on rover'], 'all'),
        ('Excavation', false, '[]'::jsonb,
          array['Excavated to design line and level',
                'Existing services potholed and protected',
                'Trench battered or shored as required'], 'all'),
        ('Trench width', false, '[]'::jsonb,
          array['Trench width per detail',
                'Clearance to adjacent services maintained'], 'all'),
        ('Foundation', false, '[]'::jsonb,
          array['Base trimmed to level',
                'Proof rolled — no soft spots',
                'Unsuitable material removed and replaced'], 'all'),
        ('Bedding / haunch', false, '[]'::jsonb,
          array['Bedding material as specified',
                'Depth per typical detail',
                'Compacted before laying'], 'all'),
        ('Conduit installation', true, '[]'::jsonb,
          array['Laid to line and level',
                'Joints made and set',
                'Spacers at specified centres',
                'Ends capped and sealed'], 'elec'),
        ('Pipe installation', true, '[]'::jsonb,
          array['Laid to line and level',
                'Joints made and set',
                'Bedding support continuous',
                'Ends capped and sealed'], 'notelec'),
        ('Draw rope / mandrel', false, '[]'::jsonb,
          array['Draw rope pulled through all ways',
                'Mandrel run clear',
                'Ways tagged and identified'], 'elec'),
        ('Registered surveyor topo — inlet & outlet', false,
          '[{"id":"co","type":"company","label":"Registered surveyor","source":"survey_cos","required":true},
            {"id":"date","type":"date","label":"Date of pickup","required":true},
            {"id":"il_in","type":"num","label":"Inlet invert level (m)","step":"0.001","required":true},
            {"id":"il_out","type":"num","label":"Outlet invert level (m)","step":"0.001","required":true}]'::jsonb,
          array['Inlet shot taken and recorded',
                'Outlet shot taken and recorded',
                'Levels checked against design'], 'drain'),
        ('CCTV survey', false,
          '[{"id":"result","type":"radio","label":"Does this line need a return visit?","required":true,
             "options":[{"v":"No return required"},{"v":"Return required","bad":true}]},
            {"id":"reason","type":"select","label":"Reason","source":"cctv_reasons","required":true,
             "visible_when":{"field":"result","equals":"No return required"}},
            {"id":"co","type":"company","label":"CCTV company","source":"cctv_cos","required":true,
             "visible_when":{"field":"reason","equals":"CCTV complete"}},
            {"id":"damage","type":"radio","label":"Damages","required":true,
             "options":[{"v":"No damages found"},{"v":"Damages found","bad":true}],
             "visible_when":{"field":"reason","equals":"CCTV complete"}}]'::jsonb,
          array['Full length surveyed or exemption recorded',
                'Footage recorded and filed',
                'Report issued to site'], 'nopressure'),
        ('Trace / marker tape', false, '[]'::jsonb,
          array['Marker tape correct colour for service',
                'Laid at specified depth above run',
                'Continuous over full length'], 'all'),
        ('Cover material', false, '[]'::jsonb,
          array['Cover material as specified',
                'Depth over service per detail',
                'No oversize or sharp material'], 'all'),
        ('Backfill', false, '[]'::jsonb,
          array['Backfill material as specified',
                'Placed in layers to spec thickness',
                'No debris or oversize material'], 'all'),
        ('Compaction test', false,
          '[{"id":"tests","type":"testlink","label":"Compaction tests","required":true}]'::jsonb,
          array['Compaction testing carried out',
                'Results within specification',
                'Test results filed against this ITC'], 'all'),
        ('Surface reinstatement', false, '[]'::jsonb,
          array['Surface reinstated to match existing',
                'Levels flush, no trip hazard',
                'Area cleaned down'], 'all'),
        ('As-built survey pickup', false,
          '[{"id":"rover","type":"select","label":"Rover used","source":"rovers","required":true},
            {"id":"op","type":"select","label":"Picked up by","source":"operators","required":true},
            {"id":"dates","type":"datelist","label":"As-built shot date(s)","required":true}]'::jsonb,
          array['Picked up on rover prior to backfill',
                'Layer named per site convention',
                'WAE file exported and uploaded'], 'all')
      ) as t(name, hold, fields, reqs, applies)
    loop
      continue when s.applies = 'elec'       and v.discipline <> 'elec';
      continue when s.applies = 'notelec'    and v.discipline =  'elec';
      continue when s.applies = 'drain'      and v.discipline <> 'drain';
      continue when s.applies = 'nopressure' and v.pressurised;

      insert into form_steps (form_version_id, step_index, name, is_hold_point, field_spec)
      values (v.fv_id, idx, s.name, s.hold, s.fields)
      returning id into step_id;

      ridx := 0;
      foreach req in array s.reqs loop
        insert into form_requirements (step_id, req_index, text)
        values (step_id, ridx, req);
        ridx := ridx + 1;
      end loop;

      idx := idx + 1;
    end loop;
  end loop;
end $$;

-- ---------------------------------------------------------------------
-- Reference lists the app reads at runtime. Kept as a table so an admin
-- can maintain them without a code change.
-- ---------------------------------------------------------------------
create table if not exists lookups (
  id      text primary key,
  label   text not null,
  items   jsonb not null
);
alter table lookups enable row level security;
create policy "read lookups" on lookups for select to authenticated using (true);
create policy "admin writes lookups" on lookups
  for all to authenticated using (is_admin()) with check (is_admin());

insert into lookups (id, label, items) values
  ('photo_slots', 'Required photos', '[
    {"id":"trench","label":"Bottom of trench"},
    {"id":"bedding","label":"Bedding"},
    {"id":"service","label":"Service installed"},
    {"id":"haunch","label":"Haunching","crew_can_skip":true},
    {"id":"cover","label":"Cover material"},
    {"id":"tape","label":"Trace / warning tape"},
    {"id":"backfill","label":"Backfill"},
    {"id":"compaction","label":"Compaction"},
    {"id":"reinstate","label":"Surface reinstatement"}]'),

  ('rovers', 'Rovers', '[
    {"id":"R1","label":"Rover 1 — Hiper VR (1041)"},
    {"id":"R2","label":"Rover 2 — Hiper VR (1042)"},
    {"id":"R3","label":"Rover 3 — Hiper VR (1043)"},
    {"id":"R4","label":"Rover 4 — Hiper VR (1044)"}]'),

  ('conduit_sizes', 'Conduit sizes', '["50mm","63mm","100mm","150mm"]'),

  ('pipe_sizes', 'Pipe sizes', '["DN100","DN150","DN225","DN300","DN375","DN450"]'),

  ('materials', 'Materials', '[
    "Orange HD PVC","White HD PVC","Red HD PVC","Black Max","Corflute","PE100","RCP"]'),

  ('end_types_elec', 'End types — electrical', '[
    "Pit","Chamber","Turn-up — room","Turn-up — board","Substation","Pillar"]'),

  ('end_types_hyd', 'End types — hydraulic', '[
    "Valve pit","Ring node","Loop tie-in","Riser","Turn-up — plant room","Hydrant","Main tie-in"]'),

  ('end_types_drain', 'End types — drainage', '[
    "Structure / pit","Turn-up","Main line connection","Grate","Headwall"]'),

  ('cctv_reasons', 'CCTV — reason no return needed', '[
    "CCTV complete",
    "Service size too small for camera",
    "Cannot negotiate a fitting",
    "Access not available",
    "Other — see comment"]'),

  ('ncr_causes', 'NCR causes', '[
    "Weather","Other trades","Builder","Design","Materials",
    "Plant / equipment","Site access","Workmanship","Utility clash"]'),

  ('weather', 'Weather', '[
    "Fine","Overcast","Showers","Rain","Storms","Hot — heat stress","Windy"]'),

  ('test_cos', 'Compaction testing companies', '[
    {"id":"t1","name":"Construction Sciences","staff":["Wayne Petrov","Lila Chen","Hamish Reid"]},
    {"id":"t2","name":"Soil Test Australia","staff":["Grant McKellar","Priya Raman"]},
    {"id":"t3","name":"GeoCheck Group","staff":["Owen Blake","Sam Duffy"]},
    {"id":"t4","name":"In-house (site crew)","staff":[]}]'),

  ('cctv_cos', 'CCTV companies', '[
    {"id":"v1","name":"PipeVision","staff":["Ryan Cole","Dana Fitzgerald"]},
    {"id":"v2","name":"Drain IQ","staff":["Mo Haddad","Kylie Ansell"]},
    {"id":"v3","name":"Aqua Survey Group","staff":["Petar Ilic","Jess Naidu"]},
    {"id":"v4","name":"In-house (site crew)","staff":[]}]'),

  ('survey_cos', 'Registered surveyors', '[
    {"id":"g1","name":"Veris","staff":["Nadia Sorenson","Craig Bellamy"]},
    {"id":"g2","name":"Harris Survey Group","staff":["Ellen Vo","Daniel Marsh"]},
    {"id":"g3","name":"LandTech Surveying","staff":["Rob Sinclair","Amrita Patel"]}]');

-- ---------------------------------------------------------------------
-- First admin
--
-- Sign in through the app once so Supabase creates your auth user, then
-- run this with your own email to make yourself admin.
-- Everyone after that you can promote from inside the app.
-- ---------------------------------------------------------------------
-- insert into profiles (id, full_name, initials, role, colour)
-- select id, 'Scott Bailey', 'SB', 'admin', '#1b4d8f'
-- from auth.users where email = 'you@yourcompany.com.au'
-- on conflict (id) do update set role = 'admin';
