-- =====================================================================
-- ITC Field — database schema
-- Paste into the Supabase SQL editor and run. Order matters.
--
-- Read this top to bottom once before running it. Every table here maps
-- to something you've already seen in the prototype.
-- =====================================================================

-- ---------------------------------------------------------------------
-- PEOPLE
-- Supabase creates auth.users for you when someone signs in. This table
-- holds the things auth.users doesn't know: role, crew, signature.
-- ---------------------------------------------------------------------
create type user_role as enum ('worker', 'leader', 'admin');

create table profiles (
  id          uuid primary key references auth.users on delete cascade,
  full_name   text not null,
  initials    text not null,
  role        user_role not null default 'worker',
  crew        text,
  colour      text default '#1b4d8f',
  signature   text,                       -- data URL of the drawn signature
  active      boolean not null default true,
  created_at  timestamptz not null default now()
);

-- Helper functions. Used by the security rules further down, so they
-- must exist first. 'security definer' lets them read profiles even
-- when the calling user's own rules would not.
create or replace function my_role() returns user_role
  language sql stable security definer as $$
  select role from profiles where id = auth.uid()
$$;

create or replace function my_crew() returns text
  language sql stable security definer as $$
  select crew from profiles where id = auth.uid()
$$;

create or replace function is_admin() returns boolean
  language sql stable security definer as $$
  select coalesce(my_role() = 'admin', false)
$$;

create or replace function is_leader_or_admin() returns boolean
  language sql stable security definer as $$
  select coalesce(my_role() in ('leader','admin'), false)
$$;

-- ---------------------------------------------------------------------
-- ZONES — buildings and roads. Admin-managed, pin position stored as a
-- fraction of the plan image (0–1), so it survives the plan being
-- re-exported at a different size.
-- ---------------------------------------------------------------------
create type zone_kind as enum ('Building', 'Road');

create table zones (
  id          uuid primary key default gen_random_uuid(),
  name        text not null unique,
  kind        zone_kind not null,
  pin_x       numeric(5,4) not null default 0.5,   -- 0–1 across the plan
  pin_y       numeric(5,4) not null default 0.5,   -- 0–1 down the plan
  sort_order  int not null default 0,
  created_at  timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- SERVICES — HV, LV, Comms, etc. Seeded, rarely changed.
-- dwg_group is what decides which drawing an ITC belongs to:
-- HV and LV share the electrical sheet, Comms and Comms Mains share theirs.
-- ---------------------------------------------------------------------
create table services (
  id          text primary key,           -- 'hv', 'lv', 'comms', …
  name        text not null,
  colour      text not null,
  dwg_group   text not null,              -- 'elec' | 'comms' | 'fire' | 'hyd' | 'storm'
  discipline  text not null,              -- 'elec' | 'hyd' | 'drain'
  pressurised boolean not null default false,   -- true = no CCTV step
  sort_order  int not null default 0
);

-- ---------------------------------------------------------------------
-- DRAWINGS — one sheet per discipline group per zone, with revisions.
-- Bumping current_rev is what flags every ITC still built to the old one.
-- ---------------------------------------------------------------------
create table drawings (
  id            uuid primary key default gen_random_uuid(),
  drawing_no    text not null,
  title         text not null,
  dwg_group     text not null,
  zone_id       uuid references zones on delete set null,
  current_rev   text not null default 'A',
  issued_date   date,
  created_at    timestamptz not null default now(),
  unique (drawing_no)
);

create table drawing_revisions (
  id          uuid primary key default gen_random_uuid(),
  drawing_id  uuid not null references drawings on delete cascade,
  rev         text not null,
  issued_date date not null,
  notes       text,
  created_by  uuid references profiles,
  created_at  timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- FORM DEFINITIONS — the inspection steps and their tick requirements.
-- Versioned: an issued ITC keeps the version it was raised against, so
-- changing a template never rewrites history.
-- ---------------------------------------------------------------------
create table form_versions (
  id          uuid primary key default gen_random_uuid(),
  service_id  text not null references services,
  version     int not null,
  is_current  boolean not null default true,
  created_at  timestamptz not null default now(),
  unique (service_id, version)
);

create table form_steps (
  id              uuid primary key default gen_random_uuid(),
  form_version_id uuid not null references form_versions on delete cascade,
  step_index      int not null,
  name            text not null,
  is_hold_point   boolean not null default false,
  -- extra fields beyond the ticks: rover pickers, test links, CCTV result.
  -- JSON because the shape differs per step and you'll keep adding to it.
  field_spec      jsonb not null default '[]'::jsonb,
  unique (form_version_id, step_index)
);

create table form_requirements (
  id          uuid primary key default gen_random_uuid(),
  step_id     uuid not null references form_steps on delete cascade,
  req_index   int not null,
  text        text not null,
  unique (step_id, req_index)
);

-- ---------------------------------------------------------------------
-- ITCs
-- ---------------------------------------------------------------------
create type itc_stage as enum ('Draft', 'For Review', 'Issued');

create table itcs (
  id              uuid primary key default gen_random_uuid(),
  itc_no          text not null unique,
  service_id      text not null references services,
  zone_id         uuid not null references zones,
  form_version_id uuid not null references form_versions,

  end_a           text not null,
  end_b           text not null,
  length_m        numeric(8,2) not null default 0,

  -- electrical runs carry several conduit sizes: [{"n":4,"size":"100mm"}]
  conduits        jsonb not null default '[]'::jsonb,
  size            text,                    -- hydraulic / stormwater instead
  material        text,
  cover           text,

  drawing_id      uuid references drawings on delete set null,
  drawing_rev     text,                    -- rev this was BUILT to

  stage           itc_stage not null default 'Draft',
  rev             text not null default 'A',
  assigned_to     uuid references profiles on delete set null,

  -- photo slots switched off for this ITC, e.g. {"haunch": true}
  na_slots        jsonb not null default '{}'::jsonb,
  -- hold points released without inspection: {"6": {"by":…, "reason":…}}
  released_holds  jsonb not null default '{}'::jsonb,

  created_by      uuid references profiles,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

create index on itcs (zone_id);
create index on itcs (service_id);
create index on itcs (assigned_to);
create index on itcs (stage);

create table itc_revisions (
  id          uuid primary key default gen_random_uuid(),
  itc_id      uuid not null references itcs on delete cascade,
  rev         text not null,
  reason      text not null,
  created_by  uuid not null references profiles,
  created_at  timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- SIGN-OFFS — the heart of it.
--
-- Append-only by design. A worker inserts their own row; nobody else can
-- change it. Several people can sign the same step, each getting their
-- own row, which is what makes the concurrency and offline problem
-- disappear: there is never anything to merge.
-- ---------------------------------------------------------------------
create table signoffs (
  id           uuid primary key default gen_random_uuid(),
  itc_id       uuid not null references itcs on delete cascade,
  step_index   int not null,
  author_id    uuid not null references profiles,

  ticks        boolean[] not null,
  comment      text default '',
  field_values jsonb not null default '{}'::jsonb,

  gps_lat      numeric(10,7),
  gps_lng      numeric(10,7),
  gps_accuracy int,

  -- set when signed across several ITCs at once; same uuid on each row
  bulk_group   uuid,

  verified_by  uuid references profiles,
  verified_at  timestamptz,

  signed_at    timestamptz not null default now(),
  -- when the device actually created it, which may predate the upload
  device_at    timestamptz,

  unique (itc_id, step_index, author_id)
);

create index on signoffs (itc_id);
create index on signoffs (author_id);
create index on signoffs (verified_by);
create index on signoffs (bulk_group);

-- Every change to a sign-off after signing needs a reason, and the
-- previous text is kept. This is the audit trail the client will want.
create table signoff_edits (
  id           uuid primary key default gen_random_uuid(),
  signoff_id   uuid not null references signoffs on delete cascade,
  reason       text not null,
  previous     text,
  edited_by    uuid not null references profiles,
  edited_at    timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- PHOTOS — nine required slots per ITC, attached to the ITC not the step.
-- The file itself goes in Supabase Storage; this row is the metadata.
-- ---------------------------------------------------------------------
create table photos (
  id           uuid primary key default gen_random_uuid(),
  itc_id       uuid not null references itcs on delete cascade,
  slot         text not null,      -- 'trench','bedding','service',…
  storage_path text not null,      -- path in the 'itc-photos' bucket
  size_kb      int,
  gps_lat      numeric(10,7),
  gps_lng      numeric(10,7),
  taken_by     uuid not null references profiles,
  taken_at     timestamptz not null default now()
);

create index on photos (itc_id);

-- ---------------------------------------------------------------------
-- DAILY PROGRESS — how far along the run someone got today.
-- One row per person per ITC per day; the metres laid falls out of the
-- difference between consecutive chainages.
-- ---------------------------------------------------------------------
create table progress_log (
  id          uuid primary key default gen_random_uuid(),
  itc_id      uuid not null references itcs on delete cascade,
  log_date    date not null,
  chainage_m  numeric(8,2) not null,
  note        text,
  logged_by   uuid not null references profiles,
  created_at  timestamptz not null default now(),
  unique (itc_id, log_date, logged_by)
);

-- ---------------------------------------------------------------------
-- COMPACTION TESTS — their own records, because one test in a shared
-- trench can cover several ITCs. Location is a point on the plan.
-- ---------------------------------------------------------------------
create table compaction_tests (
  id              uuid primary key default gen_random_uuid(),
  test_no         text not null unique,
  zone_id         uuid not null references zones,
  company         text not null,
  technician      text not null,
  test_date       date not null,
  result          text not null default 'Pass',
  mark_x          numeric(5,4) not null,   -- 0–1 across the plan
  mark_y          numeric(5,4) not null,
  technician_sig  text,
  recorded_by     uuid not null references profiles,
  created_at      timestamptz not null default now()
);

create table itc_tests (
  itc_id   uuid not null references itcs on delete cascade,
  test_id  uuid not null references compaction_tests on delete cascade,
  primary key (itc_id, test_id)
);

-- ---------------------------------------------------------------------
-- CHANGE REQUESTS — a worker can't edit someone else's sign-off, so
-- they raise one of these instead.
-- ---------------------------------------------------------------------
create type cr_status as enum ('open', 'actioned', 'rejected');

create table change_requests (
  id           uuid primary key default gen_random_uuid(),
  signoff_id   uuid not null references signoffs on delete cascade,
  itc_id       uuid not null references itcs on delete cascade,
  reason       text not null,
  status       cr_status not null default 'open',
  raised_by    uuid not null references profiles,
  raised_at    timestamptz not null default now(),
  resolved_by  uuid references profiles,
  resolved_at  timestamptz
);

-- ---------------------------------------------------------------------
-- NCRs — defects and delays with their cause, which feeds the dashboard.
-- ---------------------------------------------------------------------
create table ncrs (
  id           uuid primary key default gen_random_uuid(),
  ncr_no       text not null unique,
  itc_id       uuid references itcs on delete set null,
  zone_id      uuid references zones on delete set null,
  cause        text not null,
  days_lost    numeric(4,1) not null default 0,
  detail       text not null,
  status       text not null default 'open',
  raised_by    uuid not null references profiles,
  raised_at    timestamptz not null default now(),
  closed_by    uuid references profiles,
  closed_at    timestamptz
);

-- ---------------------------------------------------------------------
-- SITE DIARY — leading hand's daily entry. The counts come from the
-- other tables; this is only what a person adds on top.
-- ---------------------------------------------------------------------
create table diary_entries (
  id          uuid primary key default gen_random_uuid(),
  entry_date  date not null,
  author_id   uuid not null references profiles,
  weather     text,
  crew_count  text,
  plant       text,
  notes       text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (entry_date, author_id)
);

-- ---------------------------------------------------------------------
-- NOTIFICATIONS
-- ---------------------------------------------------------------------
create table notifications (
  id           uuid primary key default gen_random_uuid(),
  recipient_id uuid not null references profiles on delete cascade,
  kind         text not null,      -- 'verify' | 'cr' | 'done' | 'info'
  message      text not null,
  itc_id       uuid references itcs on delete cascade,
  read         boolean not null default false,
  created_at   timestamptz not null default now()
);

create index on notifications (recipient_id, read);

-- ---------------------------------------------------------------------
-- AUDIT LOG — append-only. No update or delete policy is ever granted,
-- so nothing in here can be altered, including by an admin.
-- ---------------------------------------------------------------------
create table audit_log (
  id          bigserial primary key,
  actor_id    uuid references profiles,
  action      text not null,
  itc_id      uuid references itcs on delete set null,
  detail      jsonb,
  created_at  timestamptz not null default now()
);

create index on audit_log (itc_id);
create index on audit_log (created_at desc);

-- ---------------------------------------------------------------------
-- Keep updated_at honest
-- ---------------------------------------------------------------------
create or replace function touch_updated_at() returns trigger
  language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

create trigger itcs_touch before update on itcs
  for each row execute function touch_updated_at();
create trigger diary_touch before update on diary_entries
  for each row execute function touch_updated_at();
