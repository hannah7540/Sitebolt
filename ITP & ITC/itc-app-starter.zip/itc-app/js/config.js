// =====================================================================
// config.js — connection details and app-wide constants
//
// Copy config.example.js to config.js and fill in your own values.
// config.js is gitignored so your keys never reach the repo.
// =====================================================================

export const SUPABASE_URL = 'https://YOUR-PROJECT.supabase.co';

// The anon key is safe in the browser. It identifies your project, not a
// user, and every table is protected by row-level security regardless.
// Never put the service_role key here — that one bypasses all security.
export const SUPABASE_ANON_KEY = 'YOUR-ANON-KEY';

export const APP = {
  name: 'ITC Field',
  project: 'CDC Marsden Park',
  jobNo: 'APP-SYD-MP',
  planImage: 'assets/site-plan.jpg',
  planWidth: 1000,          // SVG coordinate space, not pixels
  planHeight: 663,
  photoMaxEdge: 1600,       // downscale before upload — cellular friendly
  photoQuality: 0.72,
  photoBucket: 'itc-photos'
};
