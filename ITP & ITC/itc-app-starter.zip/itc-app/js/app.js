// =====================================================================
// app.js — startup and routing
//
// Keep this file small. It wires things together; the work happens in
// api.js, state.js and the view modules.
// =====================================================================

import { db, signIn, currentProfile, loadReference, loadFormVersion,
         loadItcs, loadNotifications } from './api.js';
import { S, setTheme, isAdmin, isLeader, loadQueue } from './state.js';
import { toast } from './utils.js';

// ---------------------------------------------------------------------
// Views are registered here. Each exports render(mount) and may export
// handle(event) for its own clicks.
//
// Add them one at a time as you build — see the build order in README.
// ---------------------------------------------------------------------
const VIEWS = {
  // register: () => import('./views/register.js'),
  // itc:      () => import('./views/itc.js'),
  // plan:     () => import('./views/plan.js'),
};

function tabsFor() {
  const t = [
    { id: 'register', label: 'Register' },
    { id: 'plan',     label: 'Plan' },
    { id: 'mine',     label: 'My work' }
  ];
  if (isAdmin())              t.push({ id: 'dash',     label: 'Dashboard' });
  if (isAdmin() || isLeader()) {
    t.push({ id: 'diary',    label: 'Diary' });
    t.push({ id: 'requests', label: 'Requests' });
    t.push({ id: 'gaps',     label: 'Photo gaps' });
    t.push({ id: 'ncr',      label: 'NCRs' });
  }
  if (isAdmin())              t.push({ id: 'dwg',      label: 'Drawings' });
  t.push({ id: 'tests', label: 'Tests' });
  if (isLeader())             t.push({ id: 'crew',     label: 'Crew' });
  if (isAdmin())              t.push({ id: 'audit',    label: 'Audit' });
  t.push({ id: 'me', label: 'Signature' });
  return t;
}

export async function render() {
  document.documentElement.dataset.theme = S.theme;
  document.getElementById('userBtn').textContent = S.me?.initials ?? '?';
  document.getElementById('netBtn').className = 'iconbtn' + (S.online ? '' : ' off');

  document.getElementById('tabs').innerHTML = tabsFor().map(t =>
    `<button data-tab="${t.id}" aria-current="${S.tab === t.id}">${t.label}</button>`
  ).join('');

  const main = document.getElementById('main');
  const loader = VIEWS[S.tab];

  if (!loader) {
    main.innerHTML = `<div class="empty">
      <b>${S.tab} — not built yet</b>
      Add a module in js/views/ and register it in app.js.</div>`;
    return;
  }

  const mod = await loader();
  await mod.render(main);
}

// ---------------------------------------------------------------------
// Startup
// ---------------------------------------------------------------------
async function boot() {
  setTheme(S.theme);
  loadQueue();

  const { data: { session } } = await db.auth.getSession();
  if (!session) return showAuth();

  await start();
}

async function start() {
  try {
    S.me = await currentProfile();
    if (!S.me) {
      toast('No profile yet — an admin needs to set you up');
      return showAuth();
    }

    const ref = await loadReference();
    Object.assign(S, ref);

    // form definitions, one per service
    await Promise.all(ref.services.map(async sv => {
      S.forms[sv.id] = await loadFormVersion(sv.id);
    }));

    S.itcs  = await loadItcs();
    S.notes = await loadNotifications();

    document.getElementById('auth').hidden = true;
    document.getElementById('app').hidden = false;
    await render();
  } catch (err) {
    console.error(err);
    toast('Could not load: ' + err.message);
  }
}

function showAuth() {
  document.getElementById('auth').hidden = false;
  document.getElementById('app').hidden = true;
}

// ---------------------------------------------------------------------
// Events
// ---------------------------------------------------------------------
document.getElementById('authForm').addEventListener('submit', async e => {
  e.preventDefault();
  const btn = document.getElementById('signInBtn');
  const err = document.getElementById('authErr');
  btn.disabled = true; err.hidden = true;
  try {
    await signIn(email.value.trim(), password.value);
    await start();
  } catch (ex) {
    err.textContent = ex.message;
    err.hidden = false;
  } finally {
    btn.disabled = false;
  }
});

document.getElementById('tabs').addEventListener('click', e => {
  const b = e.target.closest('[data-tab]');
  if (!b) return;
  S.tab = b.dataset.tab;
  S.openItcId = null;
  render();
});

document.getElementById('themeBtn').addEventListener('click', () => {
  setTheme(S.theme === 'light' ? 'dark' : 'light');
  render();
});

window.addEventListener('online',  () => { S.online = true;  render(); });
window.addEventListener('offline', () => { S.online = false; render(); });

boot();
