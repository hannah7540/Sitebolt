// =====================================================================
// api.js — every database call lives here
//
// Why one file: when something is wrong with the data, this is the only
// place to look. Views never talk to Supabase directly; they call these
// functions. If you swap Supabase for something else later, you rewrite
// this file and nothing else.
// =====================================================================

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { SUPABASE_URL, SUPABASE_ANON_KEY, APP } from './config.js';

export const db = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// ---------------------------------------------------------------------
// AUTH
// ---------------------------------------------------------------------
export async function signIn(email, password) {
  const { data, error } = await db.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data;
}

export async function signOut() {
  await db.auth.signOut();
}

export async function currentProfile() {
  const { data: { user } } = await db.auth.getUser();
  if (!user) return null;
  const { data, error } = await db
    .from('profiles').select('*').eq('id', user.id).single();
  if (error) throw error;
  return data;
}

// ---------------------------------------------------------------------
// REFERENCE DATA
// Loaded once at startup and cached — it barely changes and everything
// else depends on it.
// ---------------------------------------------------------------------
export async function loadReference() {
  const [zones, services, lookups, profiles, drawings] = await Promise.all([
    db.from('zones').select('*').order('sort_order'),
    db.from('services').select('*').order('sort_order'),
    db.from('lookups').select('*'),
    db.from('profiles').select('*').eq('active', true).order('full_name'),
    db.from('drawings').select('*')
  ]);

  for (const r of [zones, services, lookups, profiles, drawings]) {
    if (r.error) throw r.error;
  }

  // lookups arrive as rows; turn them into an object keyed by id
  const lk = {};
  lookups.data.forEach(r => { lk[r.id] = r.items; });

  return {
    zones: zones.data,
    services: services.data,
    lookups: lk,
    profiles: profiles.data,
    drawings: drawings.data
  };
}

export async function loadFormVersion(serviceId) {
  const { data: fv, error: e1 } = await db
    .from('form_versions')
    .select('id, version')
    .eq('service_id', serviceId)
    .eq('is_current', true)
    .single();
  if (e1) throw e1;

  const { data: steps, error: e2 } = await db
    .from('form_steps')
    .select('*, form_requirements(*)')
    .eq('form_version_id', fv.id)
    .order('step_index');
  if (e2) throw e2;

  steps.forEach(s =>
    s.form_requirements.sort((a, b) => a.req_index - b.req_index));

  return { ...fv, steps };
}

// ---------------------------------------------------------------------
// ITCs
//
// The register needs enough per row to show status without a query per
// ITC, so sign-offs and photos come along in the same request.
// ---------------------------------------------------------------------
export async function loadItcs({ zoneId = null, serviceId = null } = {}) {
  let q = db.from('itcs').select(`
    *,
    zone:zones(id, name, kind),
    service:services(id, name, colour, dwg_group, pressurised),
    drawing:drawings(id, drawing_no, current_rev),
    assignee:profiles!itcs_assigned_to_fkey(id, full_name, initials, colour),
    signoffs(id, step_index, author_id, ticks, verified_by, signed_at),
    photos(id, slot),
    progress_log(chainage_m, log_date)
  `);

  if (zoneId)    q = q.eq('zone_id', zoneId);
  if (serviceId) q = q.eq('service_id', serviceId);

  const { data, error } = await q.order('itc_no');
  if (error) throw error;
  return data;
}

export async function loadItc(id) {
  const { data, error } = await db.from('itcs').select(`
    *,
    zone:zones(*),
    service:services(*),
    drawing:drawings(*),
    assignee:profiles!itcs_assigned_to_fkey(id, full_name, initials, colour, crew),
    signoffs(*, author:profiles!signoffs_author_id_fkey(id, full_name, initials, colour, crew, signature),
                verifier:profiles!signoffs_verified_by_fkey(id, full_name, initials, colour, signature),
                signoff_edits(*)),
    photos(*, photographer:profiles!photos_taken_by_fkey(id, full_name)),
    progress_log(*, logger:profiles!progress_log_logged_by_fkey(id, full_name)),
    itc_revisions(*),
    itc_tests(compaction_tests(*))
  `).eq('id', id).single();
  if (error) throw error;
  return data;
}

export async function createItc(fields) {
  const { data, error } = await db.from('itcs').insert(fields).select().single();
  if (error) throw error;
  await logAudit('Created ITC ' + fields.itc_no, data.id);
  return data;
}

export async function createItcsBulk(rows) {
  const { data, error } = await db.from('itcs').insert(rows).select();
  if (error) throw error;
  await logAudit(`Bulk created ${rows.length} ITCs`, null);
  return data;
}

export async function updateItc(id, patch) {
  const { data, error } = await db
    .from('itcs').update(patch).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

// ---------------------------------------------------------------------
// SIGN-OFFS
//
// Insert only — nothing here overwrites. The unique constraint on
// (itc_id, step_index, author_id) is what stops a double submit from a
// flaky connection creating two rows.
// ---------------------------------------------------------------------
export async function createSignoff(fields) {
  const { data, error } = await db.from('signoffs').insert(fields).select().single();
  if (error) throw error;
  return data;
}

export async function createSignoffsBulk(rows) {
  const { data, error } = await db.from('signoffs').insert(rows).select();
  if (error) throw error;
  return data;
}

export async function verifySignoff(id, verifierId) {
  const { data, error } = await db.from('signoffs')
    .update({ verified_by: verifierId, verified_at: new Date().toISOString() })
    .eq('id', id).select().single();
  if (error) throw error;
  return data;
}

// Editing a signed record always writes the reason alongside it.
export async function editSignoff(id, newComment, reason, editorId, previous) {
  const { error: e1 } = await db.from('signoff_edits')
    .insert({ signoff_id: id, reason, previous, edited_by: editorId });
  if (e1) throw e1;

  const { data, error: e2 } = await db.from('signoffs')
    .update({ comment: newComment }).eq('id', id).select().single();
  if (e2) throw e2;
  return data;
}

// ---------------------------------------------------------------------
// PHOTOS
//
// Two steps: the file goes to Storage, then a row records where it is.
// Downscaling happens before either — see utils.js.
// ---------------------------------------------------------------------
export async function uploadPhoto(itcId, slot, blob, meta) {
  const path = `${itcId}/${slot}/${crypto.randomUUID()}.jpg`;

  const { error: upErr } = await db.storage
    .from(APP.photoBucket)
    .upload(path, blob, { contentType: 'image/jpeg', cacheControl: '31536000' });
  if (upErr) throw upErr;

  const { data, error } = await db.from('photos').insert({
    itc_id: itcId,
    slot,
    storage_path: path,
    size_kb: Math.round(blob.size / 1024),
    gps_lat: meta.lat ?? null,
    gps_lng: meta.lng ?? null,
    taken_by: meta.userId
  }).select().single();
  if (error) throw error;
  return data;
}

// Private bucket, so a short-lived signed URL rather than a public link.
export async function photoUrl(storagePath, seconds = 3600) {
  const { data, error } = await db.storage
    .from(APP.photoBucket).createSignedUrl(storagePath, seconds);
  if (error) throw error;
  return data.signedUrl;
}

export async function deletePhoto(id, storagePath) {
  await db.storage.from(APP.photoBucket).remove([storagePath]);
  const { error } = await db.from('photos').delete().eq('id', id);
  if (error) throw error;
}

// ---------------------------------------------------------------------
// PROGRESS
// ---------------------------------------------------------------------
export async function logProgress(itcId, chainage, note, userId) {
  const { data, error } = await db.from('progress_log').upsert({
    itc_id: itcId,
    log_date: new Date().toISOString().slice(0, 10),
    chainage_m: chainage,
    note,
    logged_by: userId
  }, { onConflict: 'itc_id,log_date,logged_by' }).select().single();
  if (error) throw error;
  return data;
}

// ---------------------------------------------------------------------
// COMPACTION TESTS
// ---------------------------------------------------------------------
export async function loadTests(zoneId = null) {
  let q = db.from('compaction_tests').select('*, itc_tests(itc_id, itcs(itc_no))');
  if (zoneId) q = q.eq('zone_id', zoneId);
  const { data, error } = await q.order('test_date', { ascending: false });
  if (error) throw error;
  return data;
}

export async function createTest(fields, itcIds) {
  const { data, error } = await db
    .from('compaction_tests').insert(fields).select().single();
  if (error) throw error;

  if (itcIds?.length) await linkTest(data.id, itcIds);
  return data;
}

export async function linkTest(testId, itcIds) {
  const rows = itcIds.map(itc_id => ({ itc_id, test_id: testId }));
  const { error } = await db.from('itc_tests').upsert(rows);
  if (error) throw error;
}

// ---------------------------------------------------------------------
// CHANGE REQUESTS, NCRs, DIARY, NOTIFICATIONS
// ---------------------------------------------------------------------
export async function raiseChangeRequest(fields) {
  const { data, error } = await db.from('change_requests').insert(fields).select().single();
  if (error) throw error;
  return data;
}

export async function loadChangeRequests() {
  const { data, error } = await db.from('change_requests').select(`
    *, itc:itcs(itc_no), raiser:profiles!change_requests_raised_by_fkey(full_name),
    signoff:signoffs(step_index, comment, author:profiles!signoffs_author_id_fkey(full_name))
  `).order('raised_at', { ascending: false });
  if (error) throw error;
  return data;
}

export async function raiseNcr(fields) {
  const { data, error } = await db.from('ncrs').insert(fields).select().single();
  if (error) throw error;
  return data;
}

export async function loadNcrs() {
  const { data, error } = await db.from('ncrs').select(`
    *, itc:itcs(itc_no), zone:zones(name), raiser:profiles!ncrs_raised_by_fkey(full_name)
  `).order('raised_at', { ascending: false });
  if (error) throw error;
  return data;
}

export async function saveDiary(entry) {
  const { data, error } = await db.from('diary_entries')
    .upsert(entry, { onConflict: 'entry_date,author_id' }).select().single();
  if (error) throw error;
  return data;
}

export async function notify(recipientId, kind, message, itcId = null) {
  await db.from('notifications')
    .insert({ recipient_id: recipientId, kind, message, itc_id: itcId });
}

export async function loadNotifications() {
  const { data, error } = await db.from('notifications')
    .select('*, itc:itcs(itc_no)')
    .order('created_at', { ascending: false }).limit(60);
  if (error) throw error;
  return data;
}

export async function markNotificationsRead(ids) {
  await db.from('notifications').update({ read: true }).in('id', ids);
}

// ---------------------------------------------------------------------
// AUDIT
// ---------------------------------------------------------------------
export async function logAudit(action, itcId = null, detail = null) {
  const { data: { user } } = await db.auth.getUser();
  if (!user) return;
  await db.from('audit_log')
    .insert({ actor_id: user.id, action, itc_id: itcId, detail });
}

export async function loadAudit(limit = 200) {
  const { data, error } = await db.from('audit_log')
    .select('*, actor:profiles(full_name), itc:itcs(itc_no)')
    .order('created_at', { ascending: false }).limit(limit);
  if (error) throw error;
  return data;
}

// ---------------------------------------------------------------------
// REALTIME
//
// Optional but cheap: a leader's verify queue updates the moment a
// worker signs, without anyone pulling to refresh.
// ---------------------------------------------------------------------
export function watchSignoffs(onChange) {
  return db.channel('signoffs-live')
    .on('postgres_changes',
        { event: '*', schema: 'public', table: 'signoffs' },
        onChange)
    .subscribe();
}
