// =====================================================================
// state.js — what the app currently knows and is showing
//
// One object, one render function. When state changes you call render()
// and the whole view redraws. Not the fastest approach, but by far the
// easiest to reason about, and fast enough for a few hundred rows.
// =====================================================================

export const S = {
  // who
  me: null,                 // profile row
  session: null,

  // reference data, loaded once
  zones: [], services: [], profiles: [], drawings: [], lookups: {},
  forms: {},                // serviceId -> form version with steps

  // what's on screen
  tab: 'register',
  openItcId: null,
  openStep: null,
  openZones: {},            // collapsed state per zone group
  fZone: null, fService: null, fStatus: null, q: '',

  // selection for bulk signing
  selMode: false, sel: [],

  // working data
  itcs: [], tests: [], notes: [],

  // in-progress form entry, kept per (itc, step) so it survives navigation
  drafts: {},

  // offline queue
  online: navigator.onLine,
  queue: [],

  theme: localStorage.getItem('itc-theme') || 'light',
  recent: JSON.parse(localStorage.getItem('itc-recent') || '[]')
};

export const isAdmin  = () => S.me?.role === 'admin';
export const isLeader = () => S.me?.role === 'leader';
export const canVerify = author =>
  isLeader() && author?.crew === S.me?.crew;

export function setTheme(t) {
  S.theme = t;
  localStorage.setItem('itc-theme', t);
  document.documentElement.dataset.theme = t;
}

export function pushRecent(id) {
  S.recent = [id, ...S.recent.filter(x => x !== id)].slice(0, 6);
  localStorage.setItem('itc-recent', JSON.stringify(S.recent));
}

// ---------------------------------------------------------------------
// DRAFTS — survive leaving the ITC and coming back.
// localStorage rather than memory so they also survive a browser crash
// or the phone killing the tab.
// ---------------------------------------------------------------------
const draftKey = (itc, step) => `draft|${S.me?.id}|${itc}|${step}`;

export function saveDraft(itc, step, data) {
  const empty = !data.comment
    && !data.ticks?.some(Boolean)
    && !Object.keys(data.fields || {}).length;
  if (empty) localStorage.removeItem(draftKey(itc, step));
  else localStorage.setItem(draftKey(itc, step),
       JSON.stringify({ ...data, at: Date.now() }));
}

export function getDraft(itc, step) {
  const raw = localStorage.getItem(draftKey(itc, step));
  return raw ? JSON.parse(raw) : null;
}

export function clearDraft(itc, step) {
  localStorage.removeItem(draftKey(itc, step));
}

export function myDrafts() {
  const out = [];
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (!k.startsWith(`draft|${S.me?.id}|`)) continue;
    const [, , itc, step] = k.split('|');
    out.push({ itc, step: +step, ...JSON.parse(localStorage.getItem(k)) });
  }
  return out;
}

// ---------------------------------------------------------------------
// OFFLINE QUEUE
//
// Anything written while offline goes here and replays on reconnect.
// Because sign-offs are insert-only, replay can never overwrite someone
// else's work — worst case you get a duplicate-key error, which means
// it already made it through.
// ---------------------------------------------------------------------
const QKEY = 'itc-queue';

export function loadQueue() {
  S.queue = JSON.parse(localStorage.getItem(QKEY) || '[]');
}

export function enqueue(op) {
  S.queue.push({ id: crypto.randomUUID(), at: Date.now(), ...op });
  localStorage.setItem(QKEY, JSON.stringify(S.queue));
}

export function dequeue(id) {
  S.queue = S.queue.filter(q => q.id !== id);
  localStorage.setItem(QKEY, JSON.stringify(S.queue));
}
