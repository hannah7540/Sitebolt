// =====================================================================
// utils.js — small helpers used everywhere
// =====================================================================

export const esc = s => String(s ?? '').replace(/[&<>"]/g,
  c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;' }[c]));

export function when(ts) {
  const d = (Date.now() - new Date(ts)) / 1000;
  if (d < 60)     return 'just now';
  if (d < 3600)   return Math.floor(d / 60) + ' min ago';
  if (d < 86400)  return Math.floor(d / 3600) + ' hr ago';
  if (d < 518400) return Math.floor(d / 86400) + ' days ago';
  return new Date(ts).toLocaleDateString('en-AU', { day: '2-digit', month: 'short' });
}

export const stamp = ts => new Date(ts).toLocaleString('en-AU',
  { day:'2-digit', month:'short', year:'2-digit', hour:'2-digit', minute:'2-digit' });

export const today = () => new Date().toISOString().slice(0, 10);

let toastTimer;
export function toast(msg) {
  document.querySelectorAll('.toast').forEach(t => t.remove());
  const el = document.createElement('div');
  el.className = 'toast';
  el.textContent = msg;
  el.setAttribute('role', 'status');
  document.body.appendChild(el);
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.remove(), 2800);
}

// ---------------------------------------------------------------------
// GPS — never blocks. If there's no fix in four seconds the work still
// gets recorded, just without coordinates.
// ---------------------------------------------------------------------
export function getFix() {
  return new Promise(resolve => {
    if (!navigator.geolocation) return resolve({});
    navigator.geolocation.getCurrentPosition(
      p => resolve({
        lat: p.coords.latitude,
        lng: p.coords.longitude,
        accuracy: Math.round(p.coords.accuracy)
      }),
      () => resolve({}),
      { enableHighAccuracy: true, timeout: 4000, maximumAge: 30000 }
    );
  });
}

export const gpsTxt = (lat, lng) =>
  lat && lng ? `${(+lat).toFixed(5)}, ${(+lng).toFixed(5)}` : '';

// ---------------------------------------------------------------------
// PHOTOS — downscale on the device before upload.
//
// A phone photo is 3–5 MB. On site cellular that's slow and expensive.
// 1600px on the long edge at quality 0.72 lands around 200–400 KB and is
// still plenty for QA evidence.
// ---------------------------------------------------------------------
export function downscale(file, maxEdge = 1600, quality = 0.72) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Could not read the file'));
    reader.onload = ev => {
      const img = new Image();
      img.onerror = () => reject(new Error('Not a readable image'));
      img.onload = () => {
        const scale = Math.min(1, maxEdge / Math.max(img.width, img.height));
        const canvas = document.createElement('canvas');
        canvas.width  = Math.round(img.width  * scale);
        canvas.height = Math.round(img.height * scale);
        canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
        canvas.toBlob(b => b ? resolve(b) : reject(new Error('Encode failed')),
                      'image/jpeg', quality);
      };
      img.src = ev.target.result;
    };
    reader.readAsDataURL(file);
  });
}

// ---------------------------------------------------------------------
// CONDUITS — an electrical run carries several: [{n:4,size:'100mm'}]
// ---------------------------------------------------------------------
export const conduitText = itc =>
  itc.conduits?.length
    ? itc.conduits.map(c => `${c.n} × ${c.size}`).join(' + ')
    : (itc.size || '—');

export const conduitWays = itc =>
  (itc.conduits || []).reduce((a, c) => a + (+c.n || 0), 0);

// ---------------------------------------------------------------------
// STATUS — traffic light. Grey not started, yellow ongoing, red issue,
// green complete. Anything wrong shows red and blocks issue.
// ---------------------------------------------------------------------
export function itcStatus(itc, ctx) {
  const steps    = ctx.steps ?? [];
  const signoffs = itc.signoffs ?? [];
  const signed   = new Set(signoffs.map(s => s.step_index)).size;
  const verified = new Set(signoffs.filter(s => s.verified_by).map(s => s.step_index)).size;

  const unticked   = signoffs.some(s => s.ticks?.some(t => !t));
  const gaps       = photoGaps(itc, ctx.photoSlots).length;
  const superseded = itc.drawing && itc.drawing_rev !== itc.drawing.current_rev;
  const openCr     = ctx.openCrIds?.some(id => signoffs.some(s => s.id === id));
  const openNcr    = ctx.openNcrItcIds?.includes(itc.id);

  if (unticked || gaps || superseded || openCr || openNcr)
    return { key: 'issue', label: 'Issue' };
  if (itc.stage === 'Issued')
    return { key: 'complete', label: 'Issued ' + itc.rev };
  if (steps.length && signed === steps.length && verified === steps.length)
    return { key: 'complete', label: 'Complete' };
  if (!signed) return { key: 'idle', label: 'Not started' };
  return { key: 'ongoing', label: 'Ongoing' };
}

// A photo slot is only a gap once real work has been signed on the ITC.
export function photoGaps(itc, photoSlots = []) {
  if (!itc.signoffs?.length) return [];
  const have = new Set((itc.photos || []).map(p => p.slot));
  const na   = itc.na_slots || {};
  return photoSlots.filter(s => !have.has(s.id) && !na[s.id]);
}

export function progressOf(itc) {
  const log  = (itc.progress_log || []).slice().sort((a, b) =>
    a.log_date.localeCompare(b.log_date));
  const done = log.length ? +log[log.length - 1].chainage_m : 0;
  const pc   = itc.length_m ? Math.min(100, Math.round(done / itc.length_m * 100)) : 0;
  return { log, done, pc };
}
